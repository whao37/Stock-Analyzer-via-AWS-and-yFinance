# IAM User access configuration
AWS_ACCESS_KEY="AKIA4VB53Z6ZVMNK4BC5"
AWS_SECRET_ACCESS_KEY="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"
AWS_REGION="us-east-1"

# S3 Bucket for photo objects
PHOTOGALLERY_S3_BUCKET_NAME="photobucket1-islam-2022-4150"

# MySQL Configuration
RDS_DB_HOSTNAME= 'photogallerydb.ckx9o2exqccs.us-east-1.rds.amazonaws.com'
RDS_DB_USERNAME='root'
RDS_DB_PASSWORD='Dinyar01'
RDS_DB_NAME='photogallerydb'

# DynamoDB Table
DYNAMODB_TABLE='PhotoGallery1'
USER_TABLE = 'User'

###### INSERT NEW ENVIRONMENT VARIEABLES HERE ######


####################################################