#!flask/bin/python
import email
import sys, os
sys.path.append(os.path.abspath(os.path.join('..', 'utils')))
from env import AWS_ACCESS_KEY, AWS_SECRET_ACCESS_KEY, AWS_REGION, PHOTOGALLERY_S3_BUCKET_NAME, DYNAMODB_TABLE, USER_TABLE
from flask import Flask, jsonify, abort, request, make_response, url_for
from flask import render_template, redirect, session
from flask_session import Session
import time
import exifread
import json
import uuid
import boto3
from botocore.exceptions import ClientError  
from boto3.dynamodb.conditions import Key, Attr
from datetime import datetime
from itsdangerous import URLSafeTimedSerializer
import pytz
import random
import yfinance as yf
import datetime as dt
import pandas as pd
import numpy as np
import csv
from numpy import arange
import matplotlib.pyplot as plt
from pandas import read_csv
import base64
from io import BytesIO

"""
    INSERT NEW LIBRARIES HERE (IF NEEDED)
"""





"""
"""

app = Flask(__name__, static_url_path="")

# Configure session
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)
dynamodb = boto3.resource('dynamodb', aws_access_key_id=AWS_ACCESS_KEY,
                            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
                            region_name=AWS_REGION)

table = dynamodb.Table(DYNAMODB_TABLE)
user_table = dynamodb.Table(USER_TABLE)

UPLOAD_FOLDER = os.path.join(app.root_path,'static','media')
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg','csv'])

serializer = URLSafeTimedSerializer('some_secret_key')

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def getExifData(path_name):
    f = open(path_name, 'rb')
    tags = exifread.process_file(f)
    ExifData={}
    for tag in tags.keys():
        if tag not in ('JPEGThumbnail', 'TIFFThumbnail', 'Filename', 'EXIF MakerNote'):
            key="%s"%(tag)
            val="%s"%(tags[tag])
            ExifData[key]=val
    return ExifData

def s3uploading(filename, filenameWithPath, uploadType="photos"):
    s3 = boto3.client('s3', aws_access_key_id=AWS_ACCESS_KEY,
                            aws_secret_access_key=AWS_SECRET_ACCESS_KEY)
                       
    bucket = PHOTOGALLERY_S3_BUCKET_NAME
    path_filename = uploadType + "/" + filename

    s3.upload_file(filenameWithPath, bucket, path_filename)  
    s3.put_object_acl(ACL='public-read', Bucket=bucket, Key=path_filename)
    return f'''http://{PHOTOGALLERY_S3_BUCKET_NAME}.s3.amazonaws.com/{path_filename}'''

def s3deleting(filename, uploadType="photos"):
    s3 = boto3.client('s3', aws_access_key_id=AWS_ACCESS_KEY,
                            aws_secret_access_key=AWS_SECRET_ACCESS_KEY)
                       
    bucket = PHOTOGALLERY_S3_BUCKET_NAME

    path_filename = uploadType + "/" + filename

    s3.delete_object(Bucket=bucket, Key=path_filename)


"""
    INSERT YOUR NEW FUNCTION HERE (IF NEEDED)
"""





"""
"""

"""
    INSERT YOUR NEW ROUTE HERE (IF NEEDED)
"""





"""
"""

@app.errorhandler(400)
def bad_request(error):
    """ 400 page route.

    get:
        description: Endpoint to return a bad request 400 page.
        responses: Returns 400 object.
    """
    return make_response(jsonify({'error': 'Bad request'}), 400)



@app.errorhandler(404)
def not_found(error):
    """ 404 page route.

    get:
        description: Endpoint to return a not found 404 page.
        responses: Returns 404 object.
    """
    return make_response(jsonify({'error': 'Not found'}), 404)

@app.route("/")
def default():
    #if not session.get("name"):
    return redirect("/login")
    #return render_template("index.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        response = user_table.scan(
            FilterExpression=Attr('username').eq(str(request.form['username'])) & Attr('password').eq(str(request.form['password']))
        )
        print(response)
        results = response['Items']

        for item in results:
            if item['username'] == request.form['username'] and item['password'] == request.form['password']:
                session["username"] = request.form['username']
                session["password"] = request.form['password']
                session["name"] = item['name']
                session["incorrect"] = ""
                return redirect("/home")
            else:
                session["incorrect"] = "Incorrect username or password"
    return render_template("login.html")

@app.route("/logout")
def logout():
    session["username"] = None
    return redirect("/login")

@app.route("/signup", methods=['GET', 'POST'])
def signup():
    if request.method == "POST":
        session["username"] = request.form['username']
        session["name"] = request.form['name']
        session["email"] = request.form['email']
        session["password"] = request.form['password']
        session["password1"] = request.form['password1']

        if (session["password"] == session["password1"]):
            ses = boto3.client('ses',
                region_name=AWS_REGION,
                aws_access_key_id=AWS_ACCESS_KEY,
                aws_secret_access_key=AWS_SECRET_ACCESS_KEY)

            username = session["username"]
            email = session["email"]

            serializer = URLSafeTimedSerializer('some_secret_key')
            token = serializer.dumps(email, salt='some-secret-salt-for—confirmation')

            SENDER = 'dislam6@gatech.edu'
            RECEIVER = email
            print(RECEIVER)
            # Try to send the email.
            try:
                #Provide the contents of the email.
                response = ses.send_email(
                    Destination={
                        'ToAddresses': [RECEIVER],
                    },
                    Message={
                        'Body': {
                            'Text': {
                                'Data': 'http://ec2-44-202-4-167.compute-1.amazonaws.com:5000/confirm/' + token,
                                },
                            },
                            'Subject': {
                            'Data': 'Email verification'
                            },
                    },
                    Source=SENDER
                )
            # Display an error if something goes wrong.
            except ClientError as e:
                print(e.response['Error']['Message'])
            else:
                print("Email sent! Message ID:"),
                print(response['MessageId'])
            return render_template("verificationrequest.html")
        else:
            print("Sign up failed")
    return render_template("signup.html")
    
    

@app.route("/confirm/<string:token>", methods=['GET', 'POST'])
def confirmemail(token):
    username = session["username"]
    name = session["name"]
    email = session["email"]
    password = session["password"]
    password1 = session["password1"]
    user_table.put_item(
        Item={
            "username": str(username),
            "name": name,
            "email": email,
            "password": password,
            "password1": password1
        }
    )
    
    return render_template("confirmemail.html")

@app.route("/forgotpassword")
def forgotpassword():
    return render_template("forgotpassword.html")

@app.route('/home', methods=['GET', 'POST'])
def home_page():
    """ Home page route.

    get:
        description: Endpoint to return home page.
        responses: Returns all the albums.
    """
    response = table.scan(FilterExpression=Attr('photoID').eq("thumbnail"))
    results = response['Items']

    # print(results)
    # if len(results) > 0:
    #     for index, value in enumerate(results):
    #         createdAt = datetime.strptime(str(results[index]['createdAt']), "%Y-%m-%d %H:%M:%S")
    #         createdAt_UTC = pytz.timezone("UTC").localize(createdAt)
    #         results[index]['createdAt'] = createdAt_UTC.astimezone(pytz.timezone("US/Eastern")).strftime("%B %d, %Y")
        
    #     if request.method == 'POST':
    #         for album in results:
    #             if (album['creator'] == session['username']):
    #                 response1 = table.scan(FilterExpression=Attr('albumID').eq(album['albumID']) & Attr('photoID').ne('thumbnail'))
    #                 items = response1['Items']

    #                 for item in items:
    #                     table.delete_item(Key={
    #                         "albumID" : item['albumID'],
    #                         "photoID": item['photoID']
    #                     })
    #                     s3deleting(item['filename'])

    #                 table.delete_item(Key={
    #                         "albumID" : album['albumID'],
    #                         "photoID": 'thumbnail'
    #                     })
    #                 s3deleting(album['albumID'], "thumbnails")
            
    #         user_response = user_table.scan(FilterExpression=Attr('username').eq(session['username']))
    #         user = user_response['Items']
    #         user_table.delete_item(Key={
    #             "username" : user[0]['username']
    #         })
    #         return redirect('/')
    return render_template('index.html', albums=results)

@app.route('/data', methods=['GET'])
def stock_chart():
    """ Home page route.

    get:
        description: Endpoint to return home page.
        responses: Returns all the albums.
    """
    return render_template('data.html')



@app.route('/createAlbum', methods=['GET', 'POST'])
def add_album():
    """ Create new album route.

    get:
        description: Endpoint to return form to create a new album.
        responses: Returns all the fields needed to store new album.

    post:
        description: Endpoint to send new album.
        responses: Returns user to home page.
    """
    if request.method == 'POST':
        uploadedFileURL=''
        #file = request.files['imagefile']
        ticker = request.form['name']
        money = request.form['description']

        stock_data = yf.download(ticker, start="2012-01-01", end=dt.date.today())
        stock_df = pd.DataFrame(stock_data)
        stock_df.to_csv("stock_data.csv")

        session["ticker"] = ticker

        # if file and allowed_file(file.filename):
        #     albumID = uuid.uuid4()
            
        #     filename = file.filename
        #     filenameWithPath = os.path.join(UPLOAD_FOLDER, filename)
        #     file.save(filenameWithPath)
            
        #     uploadedFileURL = s3uploading(str(albumID), filenameWithPath, "thumbnails");

        #     createdAtlocalTime = datetime.now().astimezone()
        #     createdAtUTCTime = createdAtlocalTime.astimezone(pytz.utc)

        #     table.put_item(
        #         Item={
        #             "albumID": str(albumID),
        #             "photoID": "thumbnail",
        #             "creator": session['username'],
        #             "name": name,
        #             "description": description,
        #             "thumbnailURL": uploadedFileURL,
        #             "createdAt": createdAtUTCTime.strftime("%Y-%m-%d %H:%M:%S")
        #         }
        #     )

        return redirect('/home')
    else:
        return render_template('albumForm.html')



@app.route('/album/<string:albumID>', methods=['GET', 'POST'])
def view_photos(albumID):
    """ Album page route.

    get:
        description: Endpoint to return an album.
        responses: Returns all the photos of a particular album.
    """
    # if request.method != 'POST':
    albumResponse = table.query(KeyConditionExpression=Key('albumID').eq(albumID) & Key('photoID').eq('thumbnail'))
    albumMeta = albumResponse['Items']
    print(albumMeta)
    response = table.scan(FilterExpression=Attr('albumID').eq(albumID) & Attr('photoID').ne('thumbnail'))
    items = response['Items']
    print(items)
    print(request.method)
    if request.method == 'POST':
            print("delete album")
            # #print(items[index]['createdAt'])
            
            for item in items:
                table.delete_item(Key={
                    "albumID" : item['albumID'],
                    "photoID": item['photoID']
                })
                s3deleting(item['filename'])
            #return redirect("/home")

            for album in albumMeta:
                table.delete_item(Key={
                    "albumID" : album['albumID'],
                    "photoID": 'thumbnail'
                })
            s3deleting(albumID)
            return redirect("/home")

    return render_template('viewphotos.html', photos=items, albumID=albumID, albumName=albumMeta[0]['name'])



@app.route('/display', methods=['GET', 'POST'])
def add_photo():
    """ Create new photo under album route.

    get:
        description: Endpoint to return form to create a new photo.
        responses: Returns all the fields needed to store a new photo.

    post:
        description: Endpoint to send new photo.
        responses: Returns user to album page.
    """
    # if request.method == 'POST':    
    #     uploadedFileURL=''
    #     file = request.files['imagefile']
    #     title = request.form['title']
    #     description = request.form['description']
    #     tags = request.form['tags']
        # if file and allowed_file(file.filename):
        #     photoID = uuid.uuid4()
        #     filename = file.filename
        #     filenameWithPath = os.path.join(UPLOAD_FOLDER, filename)
        #     file.save(filenameWithPath)            
            
        #     uploadedFileURL = s3uploading(filename, filenameWithPath);
            
        #     ExifData=getExifData(filenameWithPath)
        #     ExifDataStr = json.dumps(ExifData)

        #     createdAtlocalTime = datetime.now().astimezone()
        #     updatedAtlocalTime = datetime.now().astimezone()

        #     createdAtUTCTime = createdAtlocalTime.astimezone(pytz.utc)
        #     updatedAtUTCTime = updatedAtlocalTime.astimezone(pytz.utc)

        #     table.put_item(
        #         Item={
        #             "albumID": str(albumID),
        #             "photoID": str(photoID),
        #             "title": title,
        #             "description": description,
        #             "tags": tags,
        #             "photoURL": uploadedFileURL,
        #             "EXIF": ExifDataStr,
        #             "createdAt": createdAtUTCTime.strftime("%Y-%m-%d %H:%M:%S"),
        #             "updatedAt": updatedAtUTCTime.strftime("%Y-%m-%d %H:%M:%S"),
        #             "filename" : filename
        #         }
        #     )

    #     return redirect(f'''/album/{albumID}''')

    # else:

    # albumResponse = table.query(KeyConditionExpression=Key('albumID').eq(albumID) & Key('photoID').eq('thumbnail'))
    # albumMeta = albumResponse['Items']

    return render_template('photoForm.html')


@app.route('/album/<string:albumID>/photo/<string:photoID>/updatephoto', methods=['GET', 'POST'])
def updatephoto(albumID, photoID):
    if (request.method == 'POST'):

        response = table.query( KeyConditionExpression=Key('albumID').eq(albumID) & Key('photoID').eq(photoID))
        results = response['Items']

        if len(results) > 0:
            photo={}
            photo['photoID'] = results[0]['photoID']
            photo['title'] = results[0]['title']
            photo['description'] = results[0]['description']
            photo['tags'] = results[0]['tags']
            photo['photoURL'] = results[0]['photoURL']
            photo['EXIF']=json.loads(results[0]['EXIF'])
            photo['filename'] = results[0]['filename']
            photo['createdAt'] = results[0]['createdAt']

            updatedAtlocalTime = datetime.now().astimezone()
            updatedAtUTCTime = updatedAtlocalTime.astimezone(pytz.utc)

        table.delete_item(Key={
            "albumID" : albumID,
            "photoID": photoID
        })

        table.put_item(
            Item={
                "albumID": str(albumID),
                "photoID": str(photoID),
                "title": request.form['title'],
                "description": request.form['description'],
                "tags": request.form['tags'],
                "photoURL": photo['photoURL'],
                "EXIF": str(photo['EXIF']),
                "createdAt": photo['createdAt'],
                "updatedAt": updatedAtUTCTime.strftime("%Y-%m-%d %H:%M:%S"),
                "filename" : photo['filename']
            }
        )
        return redirect("/home")
    return render_template("updatephoto.html", albumID=albumID, photoID=photoID)


@app.route('/album/<string:albumID>/photo/<string:photoID>', methods=['GET', 'POST'])
def view_photo(albumID, photoID):
    """ photo page route.

    get:
        description: Endpoint to return a photo.
        responses: Returns a photo from a particular album.
    """ 
    albumResponse = table.query(KeyConditionExpression=Key('albumID').eq(albumID) & Key('photoID').eq('thumbnail'))
    albumMeta = albumResponse['Items']

    response = table.query( KeyConditionExpression=Key('albumID').eq(albumID) & Key('photoID').eq(photoID))
    results = response['Items']

    if len(results) > 0:
        photo={}
        photo['photoID'] = results[0]['photoID']
        photo['title'] = results[0]['title']
        photo['description'] = results[0]['description']
        photo['tags'] = results[0]['tags']
        photo['photoURL'] = results[0]['photoURL']
        photo['EXIF']=json.loads(results[0]['EXIF'])
        photo['filename'] = results[0]['filename']
        print( photo['photoURL'])
        createdAt = datetime.strptime(str(results[0]['createdAt']), "%Y-%m-%d %H:%M:%S")
        updatedAt = datetime.strptime(str(results[0]['updatedAt']), "%Y-%m-%d %H:%M:%S")

        createdAt_UTC = pytz.timezone("UTC").localize(createdAt)
        updatedAt_UTC = pytz.timezone("UTC").localize(updatedAt)

        photo['createdAt']=createdAt_UTC.astimezone(pytz.timezone("US/Eastern")).strftime("%B %d, %Y")
        photo['updatedAt']=updatedAt_UTC.astimezone(pytz.timezone("US/Eastern")).strftime("%B %d, %Y")
        
        tags=photo['tags'].split(',')
        exifdata=photo['EXIF']
        
        if request.method == 'POST':
            print("delete photo")
            print(photo['photoID'])
            
            table.delete_item(Key={
                "albumID" : albumID,
                "photoID": photo['photoID']
            })
            s3deleting(photo['filename'])
            return redirect("/home")

        return render_template('photodetail.html', photo=photo, tags=tags, exifdata=exifdata, albumID=albumID, albumName=albumMeta[0]['name'], photoID=photoID)
    else:
        return render_template('photodetail.html', photo={}, tags=[], exifdata={}, albumID=albumID, albumName="")



@app.route('/album/search', methods=['GET'])
def search_album_page():
    """ search album page route.

    get:
        description: Endpoint to return all the matching albums.
        responses: Returns all the albums based on a particular query.
    """ 
    query = request.args.get('query', None)    

    response = table.scan(FilterExpression=Attr('name').contains(query) | Attr('description').contains(query))
    results = response['Items']

    items=[]
    for item in results:
        if item['photoID'] == 'thumbnail':
            album={}
            album['albumID'] = item['albumID']
            album['name'] = item['name']
            album['description'] = item['description']
            album['thumbnailURL'] = item['thumbnailURL']
            items.append(album)

    return render_template('searchAlbum.html', albums=items, searchquery=query)



@app.route('/album/<string:albumID>/search', methods=['GET'])
def search_photo_page(albumID):
    """ search photo page route.

    get:
        description: Endpoint to return all the matching photos.
        responses: Returns all the photos from an album based on a particular query.
    """ 
    query = request.args.get('query', None)    

    response = table.scan(FilterExpression=Attr('title').contains(query) | Attr('description').contains(query) | Attr('tags').contains(query) | Attr('EXIF').contains(query))
    results = response['Items']

    items=[]
    for item in results:
        if item['photoID'] != 'thumbnail' and item['albumID'] == albumID:
            photo={}
            photo['photoID'] = item['photoID']
            photo['albumID'] = item['albumID']
            photo['title'] = item['title']
            photo['description'] = item['description']
            photo['photoURL'] = item['photoURL']
            items.append(photo)

    return render_template('searchPhoto.html', photos=items, searchquery=query, albumID=albumID)


# @app.route("/")
# def hello():
#     # Generate the figure **without using pyplot**.
#     #importing data set
#     stock_data = yf.download("AAPL", start="2022-01-01", end="2022-11-02")
#     stock_df = pd.DataFrame(stock_data)
#     stock_df.to_csv("stock_data.csv")

#     #visualizing the data
#     read_df = pd.read_csv("stock_data.csv")

#     read_df.set_index("Date", inplace=True)
#     read_df['Adj Close'].plot()
#     plt.ylabel("Adjusted Close Prices")
#     fig = plt.figure() 
#     fig.set_size_inches(100, 15)
#     # Save it to a temporary buffer.
#     buf = BytesIO()
#     fig.savefig(buf, format="png")
#     # Embed the result in the html output.
#     data = base64.b64encode(buf.getbuffer()).decode("ascii")
#     return f"<img src='data:image/png;base64,{data}'/>"

#def search_photo_page(albumID):
    # #importing data set
    # stock_data = yf.download("AAPL", start="2022-01-01", end="2022-11-02")
    # stock_df = pd.DataFrame(stock_data)
    # stock_df.to_csv("stock_data.csv")

    # #visualizing the data
    # read_df = pd.read_csv("stock_data.csv")
    # # with open('stock_data.csv', newline='') as csvfile:
    # #     spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
    # #     for row in spamreader:
    # #         print(', '.join(row))
    # read_df.set_index("Date", inplace=True)
    # read_df['Adj Close'].plot()
    # plt.ylabel("Adjusted Close Prices")
    # fig = plt.figure() 
    # fig.set_size_inches(100, 15)
    # plt.show()



if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=5000)


# sudo ssh -i "ece-4150-key.pem" ubuntu@ec2-44-202-4-167.compute-1.amazonaws.com
